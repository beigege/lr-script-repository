/*********************************************************************
 * Created by Mercury Interactive Windows Sockets Recorder
 *
 * Created on: Tue Dec 30 16:04:06
 *********************************************************************/

#include "lrs.h"


vuser_end()
{
    lrs_cleanup();

    return 0;
}

