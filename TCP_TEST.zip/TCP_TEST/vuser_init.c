/*********************************************************************
 * Created by Mercury Interactive Windows Sockets Recorder
 *
 * Created on: Tue Dec 30 16:04:06
 *********************************************************************/

#include "lrs.h"


vuser_init()
{
    lrs_startup(257);
	lr_load_dll("ole32.dll");
    return 0;
}

